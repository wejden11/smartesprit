#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include "produit.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <gtk/gtk.h>


//quantite ajout client
void ajouter_produit(produit x) 
{
FILE *f ;
f = fopen("produit.txt","a+");
if ( f != NULL )
fprintf(f,"%s %s %s %s %s \n",x.mois,x.annee,x.quantite,x.id,x.type) ;
fclose (f) ;
}

//quantite suprim client
int suprimer_produit(char fichier[],char iden[])
{
FILE *f ;
FILE *p ;
int n = 0 ;
char mois[20] ;
char annee[20] ;
char quantite[40] ;
char id[20] ;
char type[20];
f = fopen(fichier,"a+");
p = fopen("temporaire.txt","a");
if ( f != NULL )
{
while(fscanf(f,"%s %s %s %s %s \n",mois,annee,quantite,id,type)!=EOF)
{if (strcmp(iden,id) != 0 )
fprintf(p,"%s %s %s %s %s \n",mois,annee,quantite,id,type);
  else
n=1;
}
fclose(f);
fclose(p);

}
if (n==1)
{
 remove(fichier) ;
 rename("temporaire.txt",fichier) ;
return 1 ;
}
else
remove("temporaire.txt");
return 0 ;
}

//quantite modifier
int modifier_produit(char fichier[],produit x)
{

FILE *f ;
FILE *p ;
int n = 0 ;
char ch1[20] ;
char ch2[20] ;
char ch3[40] ;
char ident[10] ;
char sex[20];
f = fopen(fichier,"a+");
p = fopen("temporaire.txt","a");
if ( f != NULL )
{
while(fscanf(f,"%s %s %s %s %s \n",ch1,ch2,ch3,ident,sex)!=EOF)
{if(strcmp(x.id,ident)!=0)
fprintf(p,"%s %s %s %s %s \n",ch1,ch2,ch3,ident,sex);
  else
{ 
fprintf(p,"%s %s %s %s %s \n",x.mois,x.annee,x.quantite,x.id,x.type);
n=1;
}
}

fclose(f);
fclose(p);
}
 if (n==1)
{
 remove(fichier) ;
 rename("temporaire.txt",fichier) ;
return 1 ;
}
else
{
remove("temporaire.txt") ; 
return 0;
}
}

//quantite recherche

produit recherche(char fichier[],char x[])
{
int test = 0 ;
produit c ;
produit vide = {"--","--","--","--","--"};
FILE *f ;
char ch1[20] ;
char ch2[20] ;
char ch3[40] ;
char  iden[20] ;
char sex[20];
f=fopen(fichier,"a+");
if (f != NULL)
{
while(fscanf(f,"%s %s %s %s %s \n",ch1,ch2,ch3,iden,sex)!=EOF)
{
if (strcmp(x,iden)==0 )
{strcpy(c.mois,ch1);
 strcpy(c.annee,ch2);
 strcpy(c.quantite,ch3);
 strcpy(c.id,iden) ;
 strcpy(c.type,sex);
 test = 1 ;
}
}
fclose(f) ;
}
if ( test == 1 )
return(c); 
else
return (vide);
}

//quantite affichage
enum
{   Emois,
    Eannee,
    Equantite,
    EID,
    Etype,
    COLUMNS,
};

void affichage (char fichier[],GtkWidget *liste) 
{
	GtkCellRenderer *renderer ;
	GtkTreeViewColumn *column ;
	GtkTreeIter iter ;
	GtkListStore *store ;

	char mois[20] ;
	char annee[20] ;
	char quantite[40] ;
	char id [20];
	char type[20];
	store=NULL ;
	FILE *f ;
	store =gtk_tree_view_get_model(liste);
if(store == NULL )
{
renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("mois",renderer,"text",Emois,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("annee",renderer,"text",Eannee,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("quantite",renderer,"text",Equantite,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",EID,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("type",renderer,"text",Etype,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen(fichier,"a+");
if (f != NULL)
{
while(fscanf(f,"%s %s %s %s %s \n",mois,annee,quantite,id,type) != EOF )
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,Emois,mois,Eannee,annee,Equantite,quantite,EID,id,Etype,type,-1);
}
fclose(f) ;
gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL (store));
g_object_unref(store);
}
}


int verifier(char x[])
{

FILE *f;
char ch1[20];
char ch2[20];
char ch3[20];
char id[20];
char sex[20];

f=fopen("produit.txt","a+");
if (f !=NULL);
{
while(fscanf(f,"%s %s %s %s %s \n",ch1,ch2,ch3,id,sex)!=EOF)
{      
if (strcmp(x,id)==0 )
return 1 ;

}
fclose(f) ;
}
return 0 ;
}        
/*
void etage_panne(char *e1[], char *e2[]){
	FILE *f=NULL;
	char mois[20];
	char annee[20];
	char nom[20];
	char type[20];
	char quan[20];


	float valeur;

	f=fopen("produit.txt","r");
	if(f!=NULL){
		while(fscanf(f,"%s %s %s %s %s  \n",mois, annee, quan, nom,type)!=EOF){
			if(strcmp(quan,'0') != 0 )){
			
				strcpy(*e1,nom);
				strcpt(*e2,type);	
			}
		}
	}
	fclose(f);
}
*/

