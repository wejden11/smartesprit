#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "utilisateur.h"
#include "fct.h"
#include "foyer.h"
#include "reclamation.h"
#include "fonction.h"
#include "produit.h"
/* -------------------------- VARIABLES GLOBALES  ----------------------- */
int verification_bot = 0;

	/* --------------- AUTHENTIFICATION --------------------- */ 


void
on_seConnecter_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
	char email[50];
	char password[50];
	int pass = 0;

	GtkWidget *entry2, *entry1, *label45, *login, *nextWindow,*dashboard;

	login = lookup_widget(button,"login");
	entry1 = lookup_widget(login,"entry1");
	entry2 = lookup_widget(login,"entry2");
	label45 = lookup_widget(login,"label45");
	
	dashboard = create_dashboard();
	strcpy(email,gtk_entry_get_text(GTK_ENTRY(entry1)));
	strcpy(password,gtk_entry_get_text(GTK_ENTRY(entry2)));
	pass = utilisateur_login(email, password, "utilisateur.txt");

	if(pass != 0 && verification_bot == 1){
		if(pass == 1){ 
			nextWindow = create_dashboard_utilisateur();
			gtk_widget_show (nextWindow);
		}
		else if(pass == 2){
				nextWindow = create_accueil();
				gtk_widget_show (nextWindow);
		}
		else if(pass == 3){
				nextWindow =  create_affichage();
				gtk_widget_show (nextWindow);
		}
		else if(pass == 4){
				nextWindow = create_gestion_des_etudiants();
				gtk_widget_show (nextWindow);
		}
		else if(pass == 5){
				nextWindow = create_window1();
				gtk_widget_show (nextWindow);
		}	
		else if(pass == 6){
				nextWindow = create_fenetre_menu();
				gtk_widget_show (nextWindow);
			}	

		gtk_widget_show(dashboard);		
		gtk_widget_hide(login);
		
	}
	else{
		gtk_widget_show(label45);
	
	}
}
/* -------------------------- GESTION DES UTILISATEURS ----------------------- */
void
on_button1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *aj_utilisateur, *dashboard_utilisateur;


	dashboard_utilisateur=lookup_widget(objet,"dashboard_utilisateur");

	gtk_widget_hide(dashboard_utilisateur);
	aj_utilisateur=lookup_widget(objet,"aj_utilisateur");
	aj_utilisateur=create_aj_utilisateur();

	gtk_widget_show(aj_utilisateur);
}


void
on_button2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *mod_utilisateur, *dashboard_utilisateur;
	dashboard_utilisateur=lookup_widget(objet,"dashboard_utilisateur");
	gtk_widget_hide(dashboard_utilisateur);
	mod_utilisateur=lookup_widget(objet,"mod_utilisateur");
	mod_utilisateur=create_mod_utilisateur();
	gtk_widget_show(mod_utilisateur);
}


void
on_button3_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *treeview, *af_utilisateur, *dashboard_utilisateur;
	dashboard_utilisateur=lookup_widget(objet,"dashboard_utilisateur");
	gtk_widget_hide(dashboard_utilisateur);
	af_utilisateur=create_af_utilisateur();
	gtk_widget_show(af_utilisateur);
	treeview=lookup_widget(af_utilisateur,"treeview_utilisateur");
	afficher_utilisateur(treeview,"utilisateur.txt");
}


void
on_button5_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *recherche, *dashboard_utilisateur;
	dashboard_utilisateur=lookup_widget(objet,"dashboard_utilisateur");

	gtk_widget_hide(dashboard_utilisateur);
	recherche=lookup_widget(objet,"recherche");
	recherche=create_recherche();

	gtk_widget_show(recherche);
}

void
on_button_deconnecter_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *dashboard_utilisateur, *login;

	login = create_login();
	dashboard_utilisateur = lookup_widget(button,"dashboard_utilisateur");
	gtk_widget_hide(dashboard_utilisateur);
	gtk_widget_show(login);
}


void
on_check_id_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *mod1, *mod2, *mod3, *mod4, *mod5, *mod6, *mod7, *mod_erreur_id, *pInfo;
	utilisateur p;
	int a=0;
	char ch[20];
	FILE *f;
	mod1=lookup_widget(objet,"mod1");
	mod2=lookup_widget(objet,"mod2");
	mod3=lookup_widget(objet,"mod3");
	mod4=lookup_widget(objet,"mod4");
	mod5=lookup_widget(objet,"mod5");
	mod6=lookup_widget(objet,"mod6");
	mod7=lookup_widget(objet,"mod7");
	mod_erreur_id=lookup_widget(objet,"mod_erreur_id");
	int id = atoi(gtk_entry_get_text(GTK_ENTRY(mod1)));

	gtk_widget_hide(mod_erreur_id);

	if(strcmp(gtk_entry_get_text(GTK_ENTRY(mod1)),"")==0){
	gtk_widget_show(mod_erreur_id);

	}else {
	f = fopen("utilisateur.txt","r");
	if(f!=NULL){
	while(fscanf(f,"%d %d %s %s %s %s %d %d %d %d %d\n",&(p.id),&(p.role),p.prenom,p.nom,p.email,p.password,&(p.sexe),&(p.d.j),&(p.d.m),&(p.d.a),&(p.nv))!=EOF)
		{
			if(p.id==id){
				a=1;
				break;
		         }
		}
	fclose(f);
	}
	if(a==1){
	gtk_combo_box_set_active(GTK_COMBO_BOX(mod2),p.role-1);
	gtk_entry_set_text(GTK_ENTRY(mod3),p.prenom);
	gtk_entry_set_text(GTK_ENTRY(mod4),p.nom);
	gtk_entry_set_text(GTK_ENTRY(mod5),p.email);
	gtk_entry_set_text(GTK_ENTRY(mod7),p.password);
	gtk_combo_box_set_active(GTK_COMBO_BOX(mod6),p.nv-1);
	}
	else{
	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"Utilisateur introuvable");
		switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
		{
		case GTK_RESPONSE_OK:
		gtk_widget_destroy(pInfo);
		break;
		}
	}}
}


void
on_button_mod_retour_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *dashboard_utilisateur, *mod_utilisateur;

	dashboard_utilisateur = create_dashboard_utilisateur();
	mod_utilisateur = lookup_widget(button,"mod_utilisateur");
	gtk_widget_hide(mod_utilisateur);
	gtk_widget_show(dashboard_utilisateur);
}


void
on_button_mod_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *mod1, *mod2, *mod3, *mod4, *mod5, *mod6, *mod7, *pInfo;
	utilisateur u;
	int c;
	mod1=lookup_widget(objet,"mod1");
	mod2=lookup_widget(objet,"mod2");
	mod3=lookup_widget(objet,"mod3");
	mod4=lookup_widget(objet,"mod4");
	mod5=lookup_widget(objet,"mod5");
	mod6=lookup_widget(objet,"mod6");
	mod7=lookup_widget(objet,"mod7");
	u.id=atoi(gtk_entry_get_text(GTK_ENTRY(mod1)));
	u.role = gtk_combo_box_get_active(GTK_COMBO_BOX(mod2))+1;
	strcpy(u.prenom,gtk_entry_get_text(GTK_ENTRY(mod3)));
	strcpy(u.nom,gtk_entry_get_text(GTK_ENTRY(mod4)));
	strcpy(u.email,gtk_entry_get_text(GTK_ENTRY(mod5)));
	strcpy(u.password,gtk_entry_get_text(GTK_ENTRY(mod7)));
	u.nv = gtk_combo_box_get_active(GTK_COMBO_BOX(mod6))+1;
	modifier_utilisateur(u,"utilisateur.txt");
	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"Utilisateur modifié avec succès");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
}


void
on_treeview_utilisateur_row_activated  (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gint id;
	utilisateur u;
	GtkWidget *pInfo;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path)){
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,-1);
	u.id=id;
	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_QUESTION,GTK_BUTTONS_YES_NO,"Voulez-vous vraiment\nsupprimer cet utilisateur?");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_YES:
	gtk_widget_destroy(pInfo);
	supprimer_utilisateur(u,"utilisateur.txt");
	afficher_utilisateur(treeview,"utilisateur.txt");
	break;
	case GTK_RESPONSE_NO:
	gtk_widget_destroy(pInfo);
	break;
	}	
	}
}


void
on_button_af_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *treeview, *af_utilisateur;
	af_utilisateur=lookup_widget(objet,"af_utilisateur");

	gtk_widget_destroy(af_utilisateur);
	af_utilisateur=lookup_widget(objet,"af_utilisateur");
	af_utilisateur=create_af_utilisateur();

	gtk_widget_show(af_utilisateur);

	treeview=lookup_widget(af_utilisateur,"treeview_utilisateur");

	afficher_utilisateur(treeview,"utilisateur.txt");
}


void
on_button_af_retour_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *dashboard_utilisateur, *af_utilisateur;

	dashboard_utilisateur = create_dashboard_utilisateur();
	af_utilisateur = lookup_widget(button,"af_utilisateur");
	gtk_widget_hide(af_utilisateur);
	gtk_widget_show(dashboard_utilisateur);
}


void
on_button_aj_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *aj1, *aj2, *aj3, *aj4, *aj5, *aj6, *aj7, *h, *f;
	GtkWidget *aj_erreur_prenom, *aj_erreur_nom, *aj_erreur_role, *aj_erreur_email, *aj_erreur_password;
	GtkCalendar *ajc;
	utilisateur u;
	int pass = 1;
	guint day, month, year;
	aj1=lookup_widget(objet,"aj1");
	aj2=lookup_widget(objet,"aj2");
	aj3=lookup_widget(objet,"aj3");
	ajc=lookup_widget(objet,"ajc");
	h=lookup_widget(objet,"h");
	f=lookup_widget(objet,"f");
	aj4=lookup_widget(objet,"aj4");
	aj5=lookup_widget(objet,"aj5");
	aj6=lookup_widget(objet,"aj6");
	aj7 = lookup_widget(objet,"aj7");

	aj_erreur_prenom = lookup_widget(objet,"aj_erreur_prenom");
	aj_erreur_nom = lookup_widget(objet,"aj_erreur_nom");
	aj_erreur_role = lookup_widget(objet,"aj_erreur_role");
	aj_erreur_email = lookup_widget(objet,"aj_erreur_email");
	aj_erreur_password = lookup_widget(objet,"aj_erreur_password");


	gtk_widget_hide(aj_erreur_prenom);
	gtk_widget_hide(aj_erreur_nom);
	gtk_widget_hide(aj_erreur_role);
	gtk_widget_hide(aj_erreur_email);
	gtk_widget_hide(aj_erreur_password);

	u.id=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(aj1));
	strcpy(u.prenom,gtk_entry_get_text(GTK_ENTRY(aj3)));
	strcpy(u.nom,gtk_entry_get_text(GTK_ENTRY(aj4)));
	strcpy(u.email,gtk_entry_get_text(GTK_ENTRY(aj5)));
	strcpy(u.password,gtk_entry_get_text(GTK_ENTRY(aj7)));
	u.sexe=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(h))?0:1;
	gtk_calendar_get_date(GTK_CALENDAR(ajc), &day, &month, &year);
	u.d.j=year;
	u.d.m=month+1;
	u.d.a=day;
	u.role = gtk_combo_box_get_active(GTK_COMBO_BOX(aj2))+1;
	u.nv = u.role==6?gtk_combo_box_get_active(GTK_COMBO_BOX(aj6))+1:0;
	if(strcmp(u.prenom,"")==0){
	gtk_widget_show(aj_erreur_prenom);
	pass = 0;
	} 
	if(strcmp(u.nom,"")==0){
	gtk_widget_show(aj_erreur_nom);
	pass = 0;
	} 
	if(strcmp(u.email,"")==0){
	gtk_widget_show(aj_erreur_email);
	pass = 0;
	} 
	if(strcmp(u.password,"")==0){
	gtk_widget_show(aj_erreur_password);
	pass = 0;
	} 
	if(gtk_combo_box_get_active(GTK_COMBO_BOX(aj2))<0){
	gtk_widget_show(aj_erreur_role);
	pass = 0;
	}
	if(pass == 1){
	ajouter_utilisateur(u,"utilisateur.txt");
	}
}


void
on_button_ajout_retour_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *dashboard_utilisateur, *aj_utilisateur;

	dashboard_utilisateur = create_dashboard_utilisateur();
	aj_utilisateur = lookup_widget(button,"aj_utilisateur");
	gtk_widget_hide(aj_utilisateur);
	gtk_widget_show(dashboard_utilisateur);
}


void
on_chercher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *r1, *r2, *r3, *r4, *r5, *r6, *r7, *r8, *rechercher_erreur_id, *pInfo;
	char date_naissance[20], sexe[20], role[30], niveau[20];
	r1=lookup_widget(objet,"r1");
	r2=lookup_widget(objet,"r2");
	r3=lookup_widget(objet,"r3");
	r4=lookup_widget(objet,"r4");
	r5=lookup_widget(objet,"r5");
	r6=lookup_widget(objet,"r6");
	r7=lookup_widget(objet,"r7");
	r8=lookup_widget(objet,"r8");
	rechercher_erreur_id=lookup_widget(objet,"rechercher_erreur_id");

	gtk_widget_hide(rechercher_erreur_id);

	if(strcmp(gtk_entry_get_text(GTK_ENTRY(r1)),"")==0){
		gtk_widget_show(rechercher_erreur_id);
	} else {
	int id = atoi(gtk_entry_get_text(GTK_ENTRY(r1)));
	utilisateur p = chercher_utilisateur(id,"utilisateur.txt");
	if (p.id==-1){
	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"ID introuvable");
		switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
		{
		case GTK_RESPONSE_OK:
		gtk_widget_destroy(pInfo);
		break;
		}
	}
	else{
	sprintf(role,p.role==1?"Admin":p.role==2?"Technicien":p.role==3?"Nutritionniste":p.role==4?"Agent de foyer":p.role==5?"Agent de restaurant":"Etudiant");
	gtk_label_set_text(GTK_LABEL(r2),role);
	gtk_label_set_text(GTK_LABEL(r3),p.prenom);
	gtk_label_set_text(GTK_LABEL(r4),p.nom);
	gtk_label_set_text(GTK_LABEL(r5),p.email);
	sprintf(sexe,p.sexe==0?"Homme":"Femme");
	gtk_label_set_text(GTK_LABEL(r6),sexe);
	sprintf(date_naissance,"%d/%d/%d",p.d.j,p.d.m,p.d.a);
	gtk_label_set_text(GTK_LABEL(r7),date_naissance);
	sprintf(niveau,p.role==6?(p.nv==1?"1ère année":"%déme année"):"Employé",p.nv);
	gtk_label_set_text(GTK_LABEL(r8),niveau);
	}}
}


void
on_button_rechercher_retour_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *dashboard_utilisateur, *recherche;

	dashboard_utilisateur = create_dashboard_utilisateur();
	recherche = lookup_widget(button,"recherche");
	gtk_widget_hide(recherche);
	gtk_widget_show(dashboard_utilisateur);
}


void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton)){
		verification_bot = 1;
	} else {
		verification_bot = 0;
	}
}

/* -------------------------- GESTION DES MENUS -------------------------- */ 
	/* ----------------- VARIABLES GLOABLES ------------------- */ 

	int x=1,mx=1;
	int t[2]={0,0};
	char ch[100];
	menu me;
	/* -------------------------------------------------------- */
void
on_treeview1_wejden_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	gint *j;
        gint *m;
        gint *a;
        gchar  *temps;
	gchar  *entree;
        gchar *plat;
	gchar *dessert;
      
       GtkTreeIter iter;
	
	

	GtkTreeModel *model =gtk_tree_view_get_model(treeview);

	if (gtk_tree_model_get_iter(model, &iter , path))
	{ 
	  gtk_tree_model_get (GTK_LIST_STORE(model), &iter,  0, &j,1,&m,2,&a,3,&temps,4,&entree,5,&plat,6,&dessert,-1);
	  me.d.jour=j;
	  me.d.mois=m;
	  me.d.annee=a;
	  strcpy(me.temps,temps);
	  strcpy(me.menu.entree,entree);
	  strcpy(me.menu.plat_principale,plat);
	  strcpy(me.menu.dessert,dessert);


	}

}


void
on_ajouterMenu_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *ajouter;
	ajouter = create_ajout();
	gtk_widget_show (ajouter);

}


void
on_afficherMenu_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *affiche;
	affiche=lookup_widget(button,"affichage");
	strcpy(ch,"menu.txt");
	afficher_menu(lookup_widget(affiche,"treeview1_wejden"),ch);
}


void
on_modifierMenu_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *modif;
	char chj[10],chm[10],cha[10];
	modif = create_modifier();
	  gtk_widget_show (modif);

	GtkWidget* msgjour=lookup_widget(modif,"label21");
	sprintf(chj,"%d",me.d.jour);
	gtk_label_set_text(GTK_LABEL(msgjour),chj);
	gtk_widget_show(msgjour);

	GtkWidget* msgmois=lookup_widget(modif,"label23");
	sprintf(chm,"%d",me.d.mois);
	gtk_label_set_text(GTK_LABEL(msgmois),chm);
	gtk_widget_show(msgmois);


	GtkWidget* msgannee=lookup_widget(modif,"label25_wejden");
	sprintf(cha,"%d",me.d.annee);
	gtk_label_set_text(GTK_LABEL(msgannee),cha);
	gtk_widget_show(msgannee);

	gtk_entry_set_text(GTK_ENTRY(lookup_widget(modif,"entry4_wejdenn")),me.menu.entree);
	gtk_entry_set_text(GTK_ENTRY(lookup_widget(modif,"entry5_wejdennn")),me.menu.plat_principale);
	gtk_entry_set_text(GTK_ENTRY(lookup_widget(modif,"entry6_wejdennn")),me.menu.dessert);
}


void
on_supprimerMenu_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
	supprimer_menu(me.d.jour,me.d.mois,me.d.annee,me.temps);
	GtkWidget *confirmesupprimer;
	confirmesupprimer=lookup_widget(button,"affichage");
	strcpy(ch,"menu.txt");
	afficher_menu(lookup_widget(button,"treeview1_wejden"),ch);
}


void
on_rechercherMenu_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
	if (t[0]==1)
	{
	GtkWidget *entry_plat;
	char r[100];
	entry_plat=lookup_widget(button,"entry7_wejdenn");
	strcpy(r,gtk_entry_get_text(GTK_ENTRY(entry_plat) ) );
	rechercher_menu1(r);
	GtkWidget *affiche;
	affiche=lookup_widget(button,"affichage");
	strcpy(ch,"rech1.txt");
	afficher_menu(lookup_widget(affiche,"treeview1_wejden"),ch);
	}
	if (t[1]==1)
	{
	GtkWidget *Jour1,*Mois1,*Annee1,*Combobox1;
	int jo,mo,an;
	char temps1[100];
	Jour1=lookup_widget(button,"entry_jour1_wejdenn");
	Mois1=lookup_widget(button,"entry_mois1_wejdenn");
	Annee1=lookup_widget(button,"entry_annee1_wejdenn");
	Combobox1=lookup_widget(button,"combobox1_wejdenn");
	jo= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Jour1));
	mo= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Mois1));
	an= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Annee1));
	strcpy(temps1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox1)));
	rechercher_menu2(jo,mo,an,temps1);
	GtkWidget *affiche;
	affiche=lookup_widget(button,"affichage");
	strcpy(ch,"rech2.txt");
	afficher_menu(lookup_widget(affiche,"treeview1_wejden"),ch);



}
}


void
on_checkbutton1_wejdenn_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
	{t[0]=1;}
}


void
on_checkbutton2_wejdenn_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
	{t[1]=1;}
}


void
on_radiobutton2_wejdennn_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
	{x=1;}
}


void
on_radiobutton1_wejdenn_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
	{x=2;}
}


void
on_radiobutton3_wejdenn_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
	{x=3;}
}


void
on_confirmAjoutMenu_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
	menu m;
	GtkWidget *affichage;
	GtkWidget *entry_entree, *entry_plat, *entry_dessert, *entry_temps ,*Jour,*Mois,*Annee;
	GtkWidget *Ajout;
	Ajout=lookup_widget(button,"ajout");

	entry_entree=lookup_widget(button,"entry_entree_wejdenn");
	entry_plat=lookup_widget(button,"entry_plat_wejdenn");
	entry_dessert=lookup_widget(button,"entry_dinner_wejdennn");
	Jour=lookup_widget(button,"entry_jour_wejdennn");
	Mois=lookup_widget(button,"entry_mois_wejdennn");
	Annee=lookup_widget(button,"entry_annee_wejdennn");


	 strcpy(m.menu.entree,gtk_entry_get_text(GTK_ENTRY(entry_entree) ) );
	 strcpy(m.menu.plat_principale,gtk_entry_get_text(GTK_ENTRY(entry_plat) ) );
	 strcpy(m.menu.dessert,gtk_entry_get_text(GTK_ENTRY(entry_dessert) ) );
	 if (x==1){
	strcpy(m.temps,"petit_dejeuner");}
	else 
	if (x==2){
	strcpy(m.temps,"dejeuner");}
	else
	{strcpy(m.temps,"dinner");}

	 m.d.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Jour));
	 m.d.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Mois));
	 m.d.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Annee));



	ajout_menu(m);
	gtk_widget_destroy(Ajout);
}


void
on_retourAjoutMenu_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *Ajout;
	Ajout=lookup_widget(button,"ajout");
	gtk_widget_destroy(Ajout);
}


void
on_radioPDejModif_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
	{mx=1;}
}


void
on_radioDejModif_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
	{mx=2;}
}


void
on_radioDinModif_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
	{mx=3;}
}


void
on_validerModifMenu_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *entry_entree, *entry_plat, *entry_dessert,*mod;
	mod=lookup_widget(button,"modifier");
	entry_entree=lookup_widget(button,"entry4_wejdenn");
	entry_plat=lookup_widget(button,"entry5_wejdennn");
	entry_dessert=lookup_widget(button,"entry6_wejdennn");
	 strcpy(me.menu.entree,gtk_entry_get_text(GTK_ENTRY(entry_entree) ) );
	 strcpy(me.menu.plat_principale,gtk_entry_get_text(GTK_ENTRY(entry_plat) ) );
	 strcpy(me.menu.dessert,gtk_entry_get_text(GTK_ENTRY(entry_dessert) ) );
	/*if (mx==1){
	strcpy(me.temps,"petit_dejeuner");}
	else 
	if (mx==2){
	strcpy(me.temps,"dejeuner");
	}
	else
	{strcpy(me.temps,"dinner");}*/
	modifier_menu(me);
	gtk_widget_destroy(mod);
}


void
on_retourModifMenu_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *mod;
	mod=lookup_widget(button,"modifier");
	gtk_widget_destroy(mod);
}

/* -------------------------- GESTION DES ETUDIANTS ---------------------- */
	/* -------- variables gloables ------------------- */ 
		int te[5]={0,0,0,0,0};
		int xx=0,yy=0 ;
		char ch1[20] , ch2[20] , ch3[30] ;
		etudiant e ;

		GtkWidget *treeview1;

	/*-------------------------------------------------*/
void
on_treeviewEtudiant_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
        gchar *cin;
        gchar *nom;
        gchar *prenom;
        gchar *classe;
        gchar  *sexe;
	gchar  *block;
	gint *chambre;
	etudiant e ;
      

	GtkTreeModel *model =gtk_tree_view_get_model(treeview);

	if (gtk_tree_model_get_iter(model, &iter , path)){ 
	  gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&cin,1,&nom,2,&prenom,3,&classe,4,&sexe,5,&block,6,&chambre,-1);
	  strcpy(e.cin,cin);
	  strcpy(e.nom,nom);
	  strcpy(e.prenom,prenom);
	  strcpy(e.classe,classe);
	  strcpy(e.sexe,sexe);
  	  strcpy(e.block,block);
          strcpy(e.chambre,chambre);
		supprimer(e);

	afficher(treeview);


	}

}


void
on_rechercherEtudiant_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
	etudiant e ;
	/*GtkWidget *entry_rechercher;

	entry_rechercher=lookup_widget(button,"entry_rechercher");
	strcpy(e.cin,gtk_entry_get_text(GTK_ENTRY(entry_rechercher)));
	if entry_rechercher==e.cin */

	GtkWidget *entry;
	GtkWidget *labelnom;
	GtkWidget *nbResultat;
	GtkWidget *message;
	char nom[30];
	int test ;
	entry=lookup_widget(button,"button_rechercher");
	labelnom=lookup_widget(button,"entry_rechercher");
	strcpy(nom,gtk_entry_get_text(GTK_ENTRY(labelnom)));


	test=recherche_etudiant(nom);
	if (test == 1) {

	nbResultat=lookup_widget(button,"label43");
	  gtk_widget_show (nbResultat);
		}


		else if (test == 0){
	message=lookup_widget(button,"label44");
	  gtk_widget_show (message);}
}


void
on_ajouterEtudiant_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *ajout;
	ajout = create_ajout_etudiant();
	 gtk_widget_show (ajout);

}


void
on_modifierEtudiant_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *modification_infos , *authen;
	modification_infos=create_modification_infos();
	gtk_widget_show(modification_infos);
}


void
on_supprimerEtudiant_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *gestion_des_etudiants;
	gestion_des_etudiants=lookup_widget(button,"gestion_des_etudiants");
	gtk_widget_destroy(gestion_des_etudiants);
	gestion_des_etudiants=create_gestion_des_etudiants();
	gtk_widget_show (gestion_des_etudiants);
}


void
on_afficherEtudiant_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *affiche,*treeview1;
	affiche=lookup_widget(button,"afficher");
	treeview1=lookup_widget(button,"treeviewEtudiant");
	afficher(treeview1);
}

void
on_actualiserEtud_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *treeview,*w1 ,*afficherr,*ajouter,*nbResultat1,*valide ;
	GtkWidget *gestion_des_etudiants;
	gestion_des_etudiants=lookup_widget(button,"gestion_des_etudiants");
	gtk_widget_destroy(gestion_des_etudiants);

	/*GtkWidget *w2;
		GtkWidget *treeview;

		w2 = lookup_widget(objet_graphique, "InterfaceAJout") ;
		gtk_widget_destroy (w2);

		w1 = lookup_widget(objet_graphique, "InterfaceAfficher") ;
		w1 = create_InterfaceAfficher();

		gtk_widget_show (w1);
		treeview = lookup_widget(w1, "treeview1") ;
		afficher_Equipement(treeview);*/
		
		w1=lookup_widget(button,"button1");
		gestion_des_etudiants=lookup_widget(button,"gestion_des_etudiants");
		gtk_widget_destroy(gestion_des_etudiants);
		afficherr = create_gestion_des_etudiants ();
		gtk_widget_show (afficherr);
		treeview = lookup_widget(afficherr, "treeview1") ;
		afficher(treeview);
	valide=lookup_widget(button,"valider");
	nbResultat1=lookup_widget(button,"label66");
	  gtk_widget_show (nbResultat1);

}


void
on_radiobutton1_fille_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
		xx=1;
}


void
on_radiobutton1_garcon_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
		xx=0;
}


void
on_validerAjoutEtud_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
	etudiant e ;
	GtkWidget *entry_cin,*entry_nom,*entry_prenom,*entry_classe,*entry_block,*entry_sexe,*entry_chambre;
	GtkWidget *ajoutt,*nbResultat1,*valide;
	
	ajoutt=lookup_widget(button,"ajout_etudiant");
	entry_cin=lookup_widget(button,"entry_cin");
	entry_nom=lookup_widget(button,"entry_nom");
	entry_prenom=lookup_widget(button,"entry_prenom");
	entry_classe=lookup_widget(button,"entry_classe");
	entry_block=lookup_widget(button,"comboboxentry1");
	entry_chambre=lookup_widget(button,"entry_chambre");

	strcpy(e.cin,gtk_entry_get_text(GTK_ENTRY(entry_cin)));
	strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(entry_nom)));
	strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(entry_prenom)));
	strcpy(e.classe,gtk_entry_get_text(GTK_ENTRY(entry_classe)));
	strcpy(e.block,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entry_block)));

	 if (xx==1){
	strcpy(e.sexe,"femelle");}
	else if (xx==0)
	strcpy(e.sexe,"male");

	strcpy(e.chambre,gtk_entry_get_text(GTK_SPIN_BUTTON(lookup_widget(button,"spinbutton1"))));

	ajouter(e);
	gtk_widget_destroy(ajoutt);

}


void
on_quitterAjEtud_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window; 
	window = lookup_widget(button,"ajout_etudiant");
	gtk_widget_destroy(window);
}


void
on_fille_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
		yy=1;
}


void
on_garcon_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
		yy=2;
}	


void
on_validerModEtud_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
	etudiant e1 ;
	GtkWidget *entry_cin,*entry_nom,*entry_prenom,*entry_classe,*entry_block,*entry_sexe,*entry_chambre;
	GtkWidget *modification_infos,*gestion_des_etudiantss ,*authen ,*w1;

	entry_cin=lookup_widget(button,"entry9_cin");
	entry_nom=lookup_widget(button,"entry10_nom");
	entry_prenom=lookup_widget(button,"entry11_prenom");
	entry_classe=lookup_widget(button,"entry12_classe");
	entry_block=lookup_widget(button,"comboboxentry2");
	entry_chambre=lookup_widget(button,"entry_chambrem");
	authen=lookup_widget(button,"modification_infos");
	strcpy(e1.cin,gtk_entry_get_text(GTK_ENTRY(entry_cin) ) );
	strcpy(e1.nom,gtk_entry_get_text(GTK_ENTRY(entry_nom) ) );
	strcpy(e1.prenom,gtk_entry_get_text(GTK_ENTRY(entry_prenom) ) );
	strcpy(e1.classe,gtk_entry_get_text(GTK_ENTRY(entry_classe) ) );

	strcpy(e1.chambre,gtk_entry_get_text(GTK_SPIN_BUTTON(lookup_widget(button,"spinbutton2")))); 
	 if (yy==1){
	strcpy(e1.sexe,"femelle");}
	else
	{strcpy(e1.sexe,"male");}

	strcpy(e1.block,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entry_block)));

	modifier(e1);


	gtk_widget_destroy(authen);

}


void
on_quitterModEtud_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window; 
	window = lookup_widget(button,"modification_infos");
	gtk_widget_destroy(window);
}


void
on_afficherNiveau_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *sortie1 ,*sortie2 ,*sortie3 ,*sortie4 ,*sortie5;



sortie1=lookup_widget(button,"sortie1");
sortie2=lookup_widget(button,"sortie2");
sortie3=lookup_widget(button,"sortie3");
sortie4=lookup_widget(button,"sortie4");
sortie5=lookup_widget(button,"sortie5");

int nbr1 , nbr2 , nbr3 , nbr4 ,nbr5 ;
char nbr1_e[20], nbr3_e[20] , nbr2_e[20] , nbr4_e[20]  , nbr5_e[20];
	



	nbr1=nombre_etu1();
	sprintf(nbr1_e,"%d", nbr1);

	GdkColor color;
	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(sortie1,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie1),nbr1_e);


	nbr2=nombre_etu2();
	sprintf(nbr2_e,"%d", nbr2);


	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(sortie2,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie2),nbr2_e);

	nbr3=nombre_etu3();
	sprintf(nbr3_e,"%d", nbr3);


	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(sortie3,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie3),nbr3_e);

	nbr4=nombre_etu4();
	sprintf(nbr4_e,"%d", nbr4);


	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(sortie4,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie4),nbr4_e);


	nbr5=nombre_etu5();
	sprintf(nbr5_e,"%d", nbr5);

	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(sortie5,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie5),nbr5_e);
}



void
on_QuitterGesEtud_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *gestion_des_etudiantss , *authen;

	
	gestion_des_etudiantss=lookup_widget(button,"gestion_des_etudiants");
	authen=create_login();
	gtk_widget_show(authen);
	gtk_widget_destroy(gestion_des_etudiantss);
}
/* ---------------------------GESTION DES SERVICES DES RECLAMATIONS --------------------------------- */ 
	/* --------------- VARIABLES GLOBALES ---------------- */ 

	int x1 = 1;
	int x2 = 1;
	/* ------------------------------------------------- */ 
void
on_quitterRecla_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWindow *window1,*window2;
	window1 = lookup_widget(button,"fenetre_menu");
	window2 = create_login();
	gtk_widget_show(window2);
	gtk_widget_destroy(window1);
}


void
on_supprimerRecla_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *windowAfficher;
	GtkWidget *treeview1;

	windowAfficher=lookup_widget(button,"fenetre_rechercher2");
	windowAfficher=create_fenetre_rechercher2();

	gtk_widget_show(windowAfficher);

	treeview1=lookup_widget(windowAfficher,"treeviewRecher");

	afficher_reclamation(treeview1);
}


void
on_modifierRecla_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *windowModifier;
	windowModifier=create_fenetre_modifier ();
	gtk_widget_show(windowModifier);	
}


void
on_ajouterRecla_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *windowAjout ;
	windowAjout=create_fenetre_ajouter();
	gtk_widget_show(windowAjout);
}


void
on_rechercherRecla_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *windowRecherche;
	windowRecherche=create_fenetre_rechercher1 ();
	gtk_widget_show(windowRecherche);
}


void
on_afficherRecla_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *windowAfficher;
	GtkWidget *treeview1;

	windowAfficher=lookup_widget(button,"fenetre_rechercher2");
	windowAfficher=create_fenetre_rechercher2();

	gtk_widget_show(windowAfficher);

	treeview1=lookup_widget(windowAfficher,"treeviewRecher");

	afficher_reclamation(treeview1);
}


void
on_radiobutton1_nut_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
	{x1=1;}
}


void
on_radiobutton2_heb_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
	{x1=2;}
}


void
on_radiobutton3_valide_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
	{x2=1;}
}


void
on_radiobutton4_n_valide_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
	{x2=2;}
}


void
on_confirmAjoutRecla_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
	reclamation r;
	GtkWidget *fenetre_ajouter;


	GtkWidget *input1,*input2;
	char texte1[100];
	char texte2[100];

	input1=lookup_widget(button,"entry1");
	input2=lookup_widget(button,"entry2");
	if(x1==1)
	strcpy(texte1,"Nutrition");
	else 
	strcpy(texte1,"Hebergement");

	if(x2==1)
	strcpy(texte2,"Validé");
	else
	strcpy(texte2,"non_validé");


	strcpy(r.msg,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(r.type,texte1);
	strcpy(r.etat,texte2);
	strcpy(r.id,gtk_entry_get_text(GTK_ENTRY(input2)));


	ajouter_reclamation( r);

	fenetre_ajouter=lookup_widget(button,"fenetre_ajouter");
	gtk_widget_destroy(fenetre_ajouter);
}


void
on_rechercher_recl_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *windowRecherche;
	windowRecherche=create_fenetre_rechercher1 ();
	gtk_widget_show(windowRecherche);

}



void
on_backTreeRecla_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_afficher;
	fenetre_afficher=lookup_widget(button,"fenetre_rechercher2");
	gtk_widget_destroy(fenetre_afficher);
}


void
on_treeviewRecher_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* msg;
	gchar* type;
	gchar* etat;
	gchar* id;
	reclamation r;

	GtkTreeModel *model = gtk_tree_view_get_model(treeview);

	if(gtk_tree_model_get_iter(model,&iter,path))
	{
		//obtenir des valeurs de la ligne selectionnée

		gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&msg,1,&type,2,&etat,3,&id,-1);
		//copie
		strcpy(r.msg,msg);
		strcpy(r.type,type);
		strcpy(r.etat,etat);
		strcpy(r.id,id);
		//appel de la fct suppression
		supprimer_reclamation(r);
		//mise a jour
		afficher_reclamation(treeview);
	}
}


void
on_SavemodifierRecla_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *output;
	GtkWidget *input1,*input2,*combobox1,*combobox2;
	FILE *f;

	reclamation r;
	int d=0,i;
	char c,msg[100],type[100],etat[100],id[100],ident[100],message[100];
	char text1[100],text2[100];
	reclamation rec[100];

	/// collect donné ////

	input1=lookup_widget(objet_graphique,"entry4");
	strcpy(ident,gtk_entry_get_text(GTK_ENTRY(input1)));

	input2=lookup_widget(objet_graphique,"entry5");
	strcpy(message,gtk_entry_get_text(GTK_ENTRY(input2)));

	combobox1=lookup_widget(objet_graphique,"combobox1");
	if(strcmp("Nutrition",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1))))

		strcpy(text1,"Nutrition");
	else
		strcpy(text1,"Hebergement");


	combobox2=lookup_widget(objet_graphique,"combobox2");

	if(strcmp("Validé",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2))))

		strcpy(text2,"Validé");
	else
		strcpy(text2,"non_Validé");

	strcpy(r.msg,message);
	strcpy(r.type,text1);
	strcpy(r.etat,text2);
	strcpy(r.id,ident);



	output=lookup_widget(objet_graphique,"label26");

	/// rechercher////

	f=fopen("reclamation.txt","r+");
	while((c=fgetc(f)) !=EOF )
	 {
	  if(c=='\n')
	  d++;
	 }
	fclose(f);

	f=fopen("reclamation.txt","r");
	for (i=0;i<d;i++)
	{
	fscanf(f,"%s %s %s %s\n",rec[i].msg,rec[i].type,rec[i].etat,&rec[i].id);
	if (strcmp(ident,rec[i].id)==0)
	{
	strcpy(id,rec[i].id);
	}
	}

	if  (strcmp(id,ident)==0)
		{
		modifier_reclamation(r) ;// modifier 
		gtk_label_set_text(GTK_LABEL(output),"Modification terminer !");
		}





	else
		
		gtk_label_set_text(GTK_LABEL(output),"Identifiant introuvable !");

}
/* ---------------------------- GESTION DES CAPTEURS -------------------------------- */ 
	/* -------------------- VARIABLES GLOBALES ----------------------------*/

	int tt=0;
	int tp=0;
	/* --------------------------------------------------------------------*/
void
on_treeviewCap_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_toAddCap_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *acceuil;
	acceuil=lookup_widget(button,"accueil");
	
	GtkWidget *ajouter;
	ajouter = create_ajouterCap ();
	gtk_widget_show (ajouter);
	gtk_widget_destroy(acceuil);
}


void
on_toEditCap_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *acceuil;
	acceuil=lookup_widget(button,"accueil");
	gtk_widget_destroy(acceuil);
	GtkWidget *mod;
	mod = create_modifierCap ();
	  gtk_widget_show (mod);
}


void
on_toDelCap_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkTreeModel *model;
	GtkTreeSelection *selection;
	GtkTreeIter iter;
	GtkWidget *p;
	GtkWidget *label;
	gchar *id;
	p=lookup_widget(objet,"treeviewCap");
	selection=gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
	if(gtk_tree_selection_get_selected(selection,&model,&iter))
	{gtk_tree_model_get(model,&iter,0,&id,-1);
	gtk_list_store_remove(GTK_LIST_STORE(model),&iter);}
	supp_id(id);
	afficherCap(p);
}


void
on_showCap_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *tree;
	GtkWidget *aff;
	aff=lookup_widget(button,"accueil");
	tree=lookup_widget(aff,"treeviewCap");
	afficherCap(tree);
}


void
on_quitGesCap_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWindow *window1,*window2;
	window1 = lookup_widget(button,"accueil");
	window2 = create_login();
	gtk_widget_show(window2);
	gtk_widget_destroy(window1);
}


void
on_radiobuttonCap4_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
	tt=3;
}


void
on_radiobuttonCap3_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
	tt=2;
}


void
on_radiobuttonCap2_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
	tt=1;
}


void
on_radiobuttonCap1_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
	tt=0;
}


void
on_addCap_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
	capteur c;
                             
	GtkWidget* input1;
	GtkWidget *radio1,*radio2,*radio3;
	GtkWidget*radio4;
	GtkWidget* spin1,*spin2, *spin3,*spin4,*spin5;
	GtkWidget* combo1;
	GtkWidget* combo2;


	input1 = lookup_widget(objet,"stentry4");
	strcpy(c.id,gtk_entry_get_text(GTK_ENTRY(input1)));

	/*radio1 = lookup_widget(objet,"radiobuttonCap1");
	radio2 = lookup_widget(objet,"radiobutton2");
	radio3 = lookup_widget(objet,"radiobutton3");
	radio4 = lookup_widget(objet,"radiobutton4");*/
	if(tt==0)
	strcpy(c.type,"temperature");
	else if(tt==1)
	strcpy(c.type,"debit");
	else if(tt==2)
	strcpy(c.type,"fumee");
	else
	strcpy(c.type,"mouvement");

	spin1=lookup_widget(objet,"spinbutton3");
	spin2=lookup_widget(objet,"spinbutton4");
	spin3=lookup_widget(objet,"spinbutton5");
	spin4=lookup_widget(objet,"spinbutton6");
	spin5=lookup_widget(objet,"spinbutton7");

	c.captj=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin1));
	c.captm=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin2));
	c.capta=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin3));

	c.vmax=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin5));
	c.vmin=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin4));

	combo1=lookup_widget(objet,"stcombobox1");
	combo2=lookup_widget(objet,"stcombobox2");
	strcpy(c.zone,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo1)));
	strcpy(c.etage,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo2)));

	if(c.vmax>60 || c.vmin<-10){
	add(c);
	add_def(c);}
	else
	add(c);
	//sendmail("un capteur a ete ajouter");
}


void
on_backAddCap_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *add;
	add=lookup_widget(button,"ajouterCap");
	gtk_widget_destroy(add);
	GtkWidget *aff;
	aff = create_accueil ();
	  gtk_widget_show (aff);
}


void
on_searchCap_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *id,*type1,*type2,*type3,*type4,*type,*vmax,*vmin,*zone,*etage,*rech,*captj,*captm,*capta;
capteur c;
capteur p;
char nmch[30];
char reche[200];
int i=0;
int j=0;
char matrice[6][30]={"1","2","3","4","5","6","7","8","9"};
id=lookup_widget(objet,"entry6");
type1=lookup_widget(objet,"radiobutton5");
type2=lookup_widget(objet,"radiobutton6");
type3=lookup_widget(objet,"radiobutton7");
type4=lookup_widget(objet,"radiobutton8");

captj=lookup_widget(objet,"spinbutton4");
captm=lookup_widget(objet,"spinbutton5");
capta=lookup_widget(objet,"spinbutton6");

vmax=lookup_widget(objet,"spinbutton7");
vmin=lookup_widget(objet,"spinbutton8");

zone=lookup_widget(objet,"comboboxentry7");
etage=lookup_widget(objet,"comboboxentry8");


rech=lookup_widget(objet,"entrychercher");


strcpy(reche,gtk_entry_get_text(GTK_ENTRY(rech)));
FILE *f=NULL;
int v=1;
f=fopen("capt.txt","r");
while(fscanf(f,"%s %s %d %d %s %s %d %d %d \n",c.id,c.type,&c.vmax,&c.vmin,c.zone,c.etage,&c.captj,&c.captm,&c.captj)!=EOF)
        {
	if( strcmp(reche,c.id)==0){
			
			v=0;
			strcpy(p.id,c.id);
			strcpy(p.type,c.type);
			strcpy(p.zone,c.zone);
			strcpy(p.etage,c.etage);
			p.vmax=c.vmax;
			p.vmin=c.vmin;
			p.captj=c.captj;
			p.captm=c.captm;
			p.capta=c.capta;
			
			
			
	}
	else 
		{//gtk_widget_show (message);
		//gtk_label_set_text(GTK_LABEL(message),"ce cin n'existe pas");
		gtk_entry_set_text (id,"");
		gtk_entry_set_text (type,"");
		gtk_entry_set_text (captj,"");
		gtk_entry_set_text (captm,"");
		gtk_entry_set_text (capta,"");
		gtk_entry_set_text (vmax,"");
		gtk_entry_set_text (vmin,"");
		gtk_entry_set_text (zone,"");
		gtk_entry_set_text (etage,"");

}
}
if(v==0)
{
	gtk_entry_set_text (id,p.id);
	
	if(strcmp(p.type,"temperature")==0)
	{
	gtk_toggle_button_set_active(GTK_RADIO_BUTTON (type1),TRUE);
	}
	else if(strcmp(p.type,"debit")==0)
	{
	gtk_toggle_button_set_active(GTK_RADIO_BUTTON (type2),TRUE);
	}
	else if(strcmp(p.type,"fumee")==0)
	{
	gtk_toggle_button_set_active(GTK_RADIO_BUTTON (type3),TRUE);
	}
	else if(strcmp(p.type,"mouvement")==0)
	{
	gtk_toggle_button_set_active(GTK_RADIO_BUTTON (type4),TRUE);
	}
	i=0;
	while(i<10 && strcmp(matrice[i],p.zone)!=0)
	{
	i++;}
	gtk_combo_box_set_active(GTK_COMBO_BOX(zone),i);
	j=0;
	while(j<10 && strcmp(matrice[j],p.etage)!=0)
	{
	j++;}
	gtk_combo_box_set_active(GTK_COMBO_BOX(etage),j);
	
	gtk_spin_button_set_value(vmax,p.vmax);
	gtk_spin_button_set_value(vmin,p.vmin);
	gtk_spin_button_set_value(captj,p.captj);
	gtk_spin_button_set_value(captm,p.captm);
	gtk_spin_button_set_value(capta,p.capta);
	
}
}


void
on_editCap_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *id,*type1,*type2,*type3,*type4,*type,*vmax,*vmin,*zone,*etage,*rech,*captj,*captm,*capta;

	capteur p;
	char reche[200];

	id=lookup_widget(objet,"entry6");
	type1=lookup_widget(objet,"radiobutton5");
	type2=lookup_widget(objet,"radiobutton6");
	type3=lookup_widget(objet,"radiobutton7");
	type4=lookup_widget(objet,"radiobutton8");

	captj=lookup_widget(objet,"spinbutton4");
	captm=lookup_widget(objet,"spinbutton5");
	capta=lookup_widget(objet,"spinbutton6");

	vmax=lookup_widget(objet,"spinbutton7");
	vmin=lookup_widget(objet,"spinbutton8");

	zone=lookup_widget(objet,"comboboxentry7");
	etage=lookup_widget(objet,"comboboxentry8");

	rech=lookup_widget(objet,"entrychercher");


	strcpy(reche,gtk_entry_get_text(GTK_ENTRY(rech)));

	strcpy(p.id,gtk_entry_get_text(GTK_ENTRY(id)));

	p.captj=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(captj));
	p.captm=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(captm));
	p.capta=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(capta));

	p.vmax=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(vmax));
	p.vmin=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(vmin));

	type1=lookup_widget(objet,"radiobutton5");
	type2=lookup_widget(objet,"radiobutton6");
	type3=lookup_widget(objet,"radiobutton7");
	type4=lookup_widget(objet,"radiobutton8");


	if(tp==0)
	{
	strcpy(p.type,"temperatur");
	}
	else if(tp==1)
	{
	strcpy(p.type,"debit");
	}
	else if(tp==2)
	{
	strcpy(p.type,"fumee");
	}
	else if(tp==3)
	{
	strcpy(p.type,"mouvement");
	}

	zone=lookup_widget(objet,"comboboxentry7");
	strcpy(p.zone,gtk_combo_box_get_active_text(GTK_COMBO_BOX(zone)));

	etage=lookup_widget(objet,"comboboxentry8");
	strcpy(p.etage,gtk_combo_box_get_active_text(GTK_COMBO_BOX(etage)));


	supp_id(reche);
	add(p);
}


void
on_backEdit_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *mod;
	mod=lookup_widget(button,"modifier");
	gtk_widget_destroy(mod);
	GtkWidget *acceuil;
	acceuil= create_accueil ();
	  gtk_widget_show (acceuil);
}


void
on_radiobuttonCapE2_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
	tp=1;
}


void
on_radiobuttonCapE3_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
tp=2;
}


void
on_radiobuttonCapE4_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
tp=3;
}


void
on_radiobuttonCapE1_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
	tp=0;
}


void
on_capDef_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *tree;

	GtkWidget *aff;

	aff=lookup_widget(button,"capdef");

	tree=lookup_widget(aff,"treeviewCapDef");

	afficherdef(tree);
}

/* -------------------------- GESTION DU STOCK -------------------------- */ 
	/* ------------ variables globales -----------------------*/ 

	int xy=0;
	int k=0;
	int y=0;
	int z=0 ;
	int ee=0;
	int q=0;
	char iden[20];
	produit cli ;
	int w ;
	int m;
	char idd[20];
	/* ----------------------------------------------------- */ 
void
on_treeview1khlil_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
gchar* mois ;
gchar* annee;
gchar* quantite;
gchar* nom;
gchar* type;
produit c;

char fichier[]={"produit.txt"};

GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if(gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&mois,1,&annee,2,&quantite,3,&nom,4,&type,-1);

strcpy(c.id,nom);
strcpy(c.mois,mois);
strcpy(c.annee,annee);
strcpy(c.quantite,quantite);
strcpy(c.type,type);

strcpy(idd,c.id);

affichage(fichier,treeview);
}

}


gboolean
on_treeview1khlil_select_cursor_row    (GtkTreeView     *treeview,
                                        gboolean         start_editing,
                                        gpointer         user_data)
{

  return FALSE;
}


void
on_button1khlil_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
	char text1[20];
char text2[40];
strcpy(text1,"nourriture");
strcpy(text2,"nettoyage");
GtkWidget *input,*input1;
GtkWidget *combobox1khlil;
input=create_window2();
gtk_widget_show(input);
combobox1khlil=lookup_widget(input,"combobox1khlil");
gtk_combo_box_append_text(GTK_COMBO_BOX(combobox1khlil),text1);
gtk_combo_box_append_text(GTK_COMBO_BOX(combobox1khlil),text2);

input1=lookup_widget(objet,"window1");
gtk_widget_destroy(input1);
}


void
on_button9khlil_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
	char fichier[]={"produit.txt"};
GtkWidget *input,*input1,*treeview1khlil;
input=lookup_widget(objet,"window1");
input=create_window1();
gtk_widget_show(input);
input1=lookup_widget(objet,"window1");
gtk_widget_destroy(input1);
gtk_widget_show(input);
treeview1khlil=lookup_widget(input,"treeview1khlil");
affichage(fichier,treeview1khlil);
}


void
on_button2khlil_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1,*window4,*input2,*treeview1,*output,*output1,*output2,*output3,*output4,*output5,*output6;
GtkWidget *input,*input1;

char fichierr[]={"produit.txt"};
char x [20];
int s ;
int n=0 ;
produit c;


window1=lookup_widget(objet,"window1");
input2=lookup_widget(objet,"entry10khlil");
strcpy(x,gtk_entry_get_text(GTK_ENTRY(input2)));
s=verifier(x);
while((strcmp(x,"")!=0)&&(n==0))
{
if ( s==0)
{
output5 = lookup_widget(objet,"label37khlil") ;
gtk_label_set_text(GTK_LABEL(output5),"produit introuvable");
n=1;
}
else
{window4=lookup_widget(objet,"window4");
window4=create_window4();
gtk_widget_show(window4);
gtk_widget_destroy(window1);
strcpy(iden,x);
n=1;
}
}
if(n==0)
{
output6 = lookup_widget(objet,"label37khlil") ;
gtk_label_set_text(GTK_LABEL(output6),"il faut donner le nom");
}
}


void
on_button3khlil_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *input3, *input1;
GtkWidget *label99khlil;
label99khlil = lookup_widget(button,"label99khlil");
if(strcmp(idd,"")==0){
gtk_widget_show(label99khlil);
} else {
input3=lookup_widget(button,"window6");
input3=create_window6();
gtk_widget_show(input3);
input1=lookup_widget(button,"window1");
gtk_widget_destroy(input1);
}
}


void
on_QuitGesStock_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWindow *window1,*window2;
	window1 = lookup_widget(button,"window1");
	window2 = create_login();
	gtk_widget_show(window2);
}


void
on_button6khlil_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *input1, *input2,*input3,*input4,*output,*output1,*output2;
GtkWidget *window_ajouter,*combobox1khlil;
produit c;
int test ;
int n = 0 ;
char a[20];
char b[20];



combobox1khlil=lookup_widget(objet_graphique,"combobox1khlil");
window_ajouter=lookup_widget(objet_graphique,"window2");
input1=lookup_widget(objet_graphique,"spinbutton2khlil");
input2=lookup_widget(objet_graphique,"spinbutton3khlil");
input3=lookup_widget(objet_graphique,"entry4khlil");
input4=lookup_widget(objet_graphique,"entry5khlil");
if(strcmp("nourriture",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1khlil)))==0)
strcpy(c.type,"nourriture");
if(strcmp("nettoyage",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1khlil)))==0)
strcpy(c.type,"nettoyage");

sprintf(a,"%d",gtk_spin_button_get_value_as_int(GTK_ENTRY(input1)));
sprintf(b,"%d",gtk_spin_button_get_value_as_int(GTK_ENTRY(input2)));
strcpy(c.mois,a);
strcpy(c.annee,b);
strcpy(c.quantite,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(c.id,gtk_entry_get_text(GTK_ENTRY(input4)));

test = verifier(c.id);
while((strcmp(c.mois,"")!=0)&&(strcmp(c.annee,"")!=0)&&(strcmp(c.quantite,"")!=0)&&(strcmp(c.id,"")!=0)&&(n==0))
{
if(test==1)
{
output = lookup_widget(objet_graphique,"label7khlil") ;
gtk_label_set_text(GTK_LABEL(output),"identite deja existe");
n=1;
}
else
{
cli=c ;
GtkWidget *input0,*input00;
input0=lookup_widget(objet_graphique,"window5");
input0=create_window5();
gtk_widget_show(input0);
input00=lookup_widget(objet_graphique,"window2");
gtk_widget_destroy(input00);
n=1;

}
}
if(n==0)
{
output2=lookup_widget(objet_graphique,"label7khlil");
gtk_label_set_text(GTK_LABEL(output2),"remplir tout les informations!");
}
}


void
on_button5khlil_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *input,*input1;
input=lookup_widget(objet,"window1");
input=create_window1();
gtk_widget_show(input);
input1=lookup_widget(objet,"window2");
gtk_widget_destroy(input1);
}


void
on_radiobutton3khlil_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=1;}
}


void
on_radiobutton4khlil_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=2;}
}


void
on_button12khlil_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input1,*input2,*input3,*input4,*output1,*output2,*output3;
GtkWidget *window3;

produit x;
int m ;
int test ;
int n=0;
char fichierr[]={"produit.txt"};

window3=lookup_widget(objet,"window3");
if(y==1)
strcpy(x.type,"nourriture");
if(y==2)
strcpy(x.type,"nettoyage");


input1=lookup_widget(objet,"entry6khlil");
input2=lookup_widget(objet,"entry7khlil");
input3=lookup_widget(objet,"entry9khlil");
input4=lookup_widget(objet,"entry8khlil");


strcpy(x.mois,gtk_entry_get_text(GTK_ENTRY(input1)));//mois modifiée
strcpy(x.annee,gtk_entry_get_text(GTK_ENTRY(input2)));//annee modifiée
strcpy(x.id,gtk_entry_get_text(GTK_ENTRY(input3)));//id 
strcpy(x.quantite,gtk_entry_get_text(GTK_ENTRY(input4)));//quantite modifiéé



//partie validation de modification

test = verifier(x.id);

while((strcmp(x.mois,"")!=0)&&(strcmp(x.annee,"")!=0)&&(strcmp(x.quantite,"")!=0)&&(strcmp(x.id,"")!=0)&&(n==0))
{
if (test==1)
{

m =modifier_produit(fichierr,x);
output1 = lookup_widget(objet,"label35khlil") ;
gtk_label_set_text(GTK_LABEL(output1),"le produit modifié avec succes");
n=1;
}
else
{
output2 = lookup_widget(objet,"label35khlil") ;
gtk_label_set_text(GTK_LABEL(output2),"identifiant n'existe pas");
n=1;
}
}
if(n==0)
{
output3 = lookup_widget(objet,"label35khlil") ;
gtk_label_set_text(GTK_LABEL(output3),"il faut remplir tout les information");
}
}


void
on_button8kkhlil_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *input,*input1;
input=lookup_widget(button,"window1");
input=create_window1();
gtk_widget_show(input);
input1=lookup_widget(button,"window3");
gtk_widget_destroy(input1);
}


void
on_button10khlil_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window3;
GtkWidget *output,*output1,*output2,*output3,*output4;
produit c ;
char fichier[]={"produit.txt"};
c=recherche(fichier,iden);
output = lookup_widget(objet,"label29khlil") ;
gtk_label_set_text(GTK_LABEL(output),c.mois);
output1 = lookup_widget(objet,"label30khlil") ;
gtk_label_set_text(GTK_LABEL(output1),c.annee);
output2 = lookup_widget(objet,"label33khlil") ;
gtk_label_set_text(GTK_LABEL(output2),c.id);
output3 = lookup_widget(objet,"label32khlil") ;
gtk_label_set_text(GTK_LABEL(output3),c.quantite);
output4 = lookup_widget(objet,"label31khlil") ;
gtk_label_set_text(GTK_LABEL(output4),c.type);
}


void
on_button11kkhlil_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input,*input1,*input3,*input4,*input5;
if(z==1)
{
input=lookup_widget(objet,"window3");
input=create_window3();
gtk_widget_show(input);
input1=lookup_widget(objet,"window1");
gtk_widget_destroy(input1);
input3=lookup_widget(objet,"window4");
gtk_widget_destroy(input3);
}
if(z==2)
{
input4=lookup_widget(objet,"window1");
input4=create_window1();
gtk_widget_show(input4);
input5=lookup_widget(objet,"window4");
gtk_widget_destroy(input5);

}
}


void
on_radiobutton5khlil_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{z=1;}
}


void
on_radiobutton6khlil_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{z=2;}
}


void
on_button13khlil_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	int n = 0 ;
while((m!=w)&&(n==0))
{
if(w==1)
{
ajouter_produit(cli);
GtkWidget *input,*input1,*input2;
input=lookup_widget(objet_graphique,"window1");
input=create_window1();
gtk_widget_show(input);
input1=lookup_widget(objet_graphique,"window2");
gtk_widget_destroy(input1);
input2=lookup_widget(objet_graphique,"window5");
gtk_widget_destroy(input2);
n=1;
}
if(m==1)
{
GtkWidget *input3,*input4;
input4=lookup_widget(objet_graphique,"window2");
input4=create_window2();
gtk_widget_show(input4);
input3=lookup_widget(objet_graphique,"window5");
gtk_widget_destroy(input3);
n=1;
}
}
if(n==0)
{
GtkWidget *output2,*input5;
input5=lookup_widget(objet_graphique,"window5");
output2 = lookup_widget(objet_graphique,"label44khlil") ;
gtk_label_set_text(GTK_LABEL(output2),"choisir oui ou non");
}
}


void
on_checkbutton1khlil_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{w=1;}
else
{w=0;}
}


void
on_checkbutton2khlil_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{m=1;}
else
{m=0;}
}


void
on_button14khlil_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *spinbutton1khlil;
GtkWidget *input,*input1,*input2,*input3,*input4,*treeview1khlil;
char fichierr[]={"produit.txt"};
int a,s ;
spinbutton1khlil=lookup_widget(objet_graphique,"spinbutton1khlil");
a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton1khlil));
if(a==1)
{
s=suprimer_produit(fichierr,idd);
input=lookup_widget(objet_graphique,"window1");
input=create_window1();
gtk_widget_show(input);
input1=lookup_widget(objet_graphique,"window6");
gtk_widget_destroy(input1);
//gtk_widget_show(input2);//remarque
treeview1khlil=lookup_widget(input,"treeview1khlil");
affichage(fichierr,treeview1khlil);
}
if(a==0)
{
input3=lookup_widget(objet_graphique,"window6");
gtk_widget_destroy(input3);
input2=lookup_widget(objet_graphique,"window1");
input2=create_window1();
gtk_widget_show(input2);
treeview1khlil=lookup_widget(input3,"treeview1khlil");
affichage(fichierr,treeview1khlil);
}
}


void
on_button37retour_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button4khlil_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window_ajouter,*input2,*treeview1;

	char fichier[]={"test.txt"};
	char fichierr[]={"produit.txt"};
	char x [20];
	produit c ;
	//partie recherche identite
	window_ajouter=lookup_widget(objet,"window1");
	input2=lookup_widget(objet,"entry1khlil");
	strcpy(x,gtk_entry_get_text(GTK_ENTRY(input2)));
	c=recherche(fichierr,x);
	//partie fichier test
	FILE *f;
	f = fopen(fichier,"a+");
	if ( f != NULL )
	fprintf(f,"%s %s %s %s %s \n",c.mois,c.annee,c.quantite,c.id,c.type) ;
	fclose (f) ;

	//partie affichage
	GtkWidget *input,*input1;
	input=lookup_widget(objet,"window1");
	input=create_window1();
	gtk_widget_show(input);
	input1=lookup_widget(objet,"window1");
	gtk_widget_destroy(input1);
	gtk_widget_show(input);
	treeview1=lookup_widget(input,"treeview1");
	affichage(fichier,treeview1);
	remove(fichier);
}

/* -------------------------------- DASHBOARD ------------------------------ */
/*void
on_listeAlarmante_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *treeview, *alarme, *dashboard_utilisateur;
	dashboard_utilisateur=lookup_widget(button,"dashboard_utilisateur");
	gtk_widget_hide(dashboard_utilisateur);
	alarme=create_alarme();
	gtk_widget_show(alarme);
	treeview=lookup_widget(alarme,"treeview_alarme");
	afficher_alarme(treeview);
}


void
on_meuiMenu_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *affiche;
	affiche=lookup_widget(button,"affichage");
	meilleur_menu(lookup_widget(affiche,"treeview1_wejden"));
}



void
on_reptureStock_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWindow *window1,*window2;
	window1 = lookup_widget(button,"dashboard");
	window2 = create_window7();
	gtk_widget_show(window2);
}

*/
void
on_quitGesMenu_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWindow *window1,*window2;
	window1 = lookup_widget(button,"affichage");
	window2 = create_login();
	gtk_widget_show(window2);
	gtk_widget_destroy(window1);	
}

/* ----------------------------- TABLEAU DE BOARD -------------------------------*/


void
on_listeCapDef_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *tree,*aff;
	aff=lookup_widget(button,"dashboard");
	tree=lookup_widget(aff,"treeviewCapDef");
	afficherdef(tree);
}


void
on_servicePR_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
	char type[100];
	char text[100];
	GtkWidget *output;
	output=lookup_widget(button,"label29");

	leplusreclamer(type);
	strcpy(text,type);

	gtk_widget_show(output);
	gtk_label_set_text(GTK_LABEL(output),text);
}


void
on_affListeCapAlar_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *dashboard,*treeview;
	dashboard = lookup_widget(button,"dashboard");
	treeview=lookup_widget(dashboard,"treeview_alarme");
	afficher_alarme(treeview);
}


void
on_affEtudiantPNiveau_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *sortie1 ,*sortie2 ,*sortie3 ,*sortie4 ,*sortie5;

	sortie1=lookup_widget(button,"sortie1");
	sortie2=lookup_widget(button,"sortie2");
	sortie3=lookup_widget(button,"sortie3");
	sortie4=lookup_widget(button,"sortie4");
	sortie5=lookup_widget(button,"sortie5");

	int nbr1 , nbr2 , nbr3 , nbr4 ,nbr5 ;
	char nbr1_e[20], nbr3_e[20] , nbr2_e[20] , nbr4_e[20]  , nbr5_e[20];
	



	nbr1=nombre_etu1();
	sprintf(nbr1_e,"%d", nbr1);

	GdkColor color;
	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(sortie1,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie1),nbr1_e);


	nbr2=nombre_etu2();
	sprintf(nbr2_e,"%d", nbr2);


	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(sortie2,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie2),nbr2_e);

	nbr3=nombre_etu3();
	sprintf(nbr3_e,"%d", nbr3);


	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(sortie3,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie3),nbr3_e);

	nbr4=nombre_etu4();
	sprintf(nbr4_e,"%d", nbr4);


	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(sortie4,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie4),nbr4_e);


	nbr5=nombre_etu5();
	sprintf(nbr5_e,"%d", nbr5);

	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(sortie5,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie5),nbr5_e);
}


void
on_listeProdReptureStock_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_AffmeilleurMenu_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *affiche;
	affiche=lookup_widget(button,"dashboard");
	meilleur_menu(lookup_widget(affiche,"treeview_best"));
}

