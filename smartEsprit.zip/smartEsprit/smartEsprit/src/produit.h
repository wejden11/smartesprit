#include <gtk/gtk.h>
typedef struct 
{   
    char mois[20] ;
    char annee[20] ;
    char quantite[40] ;
    char id[10] ;
    char type[20];
}produit;




void affichage (char fichier[],GtkWidget *liste) ; 

produit recherche(char fichier[],char x[] );

void ajouter_produit(produit x) ; 

int suprimer_produit(char fichier[],char iden[]) ;

int modifier_produit(char fichier[],produit x) ;


int verifier(char x[]) ;




