#include <gtk/gtk.h>


void
on_button1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_button5_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_deconnecter_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_check_id_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mod_retour_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_mod_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_utilisateur_row_activated  (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_af_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_af_retour_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_aj_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_ajout_retour_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_chercher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_rechercher_retour_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_alarme_retour_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_seConnecter_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_wejden_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_ajouterMenu_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficherMenu_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifierMenu_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimerMenu_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_rechercherMenu_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton1_wejdenn_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_wejdenn_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_wejdennn_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_wejdenn_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_wejdenn_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_confirmAjoutMenu_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_retourAjoutMenu_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_radioPDejModif_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radioDejModif_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radioDinModif_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_validerModifMenu_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_retourModifMenu_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeviewEtudiant_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_rechercherEtudiant_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajouterEtudiant_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifierEtudiant_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimerEtudiant_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficherEtudiant_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualiserEtud_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_fille_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_garcon_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_validerAjoutEtud_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_quitterAjEtud_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_fille_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_garcon_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_validerModEtud_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_quitterModEtud_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficherNiveau_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_retourNivEtud_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_QuitterGesEtud_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_quitterRecla_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimerRecla_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifierRecla_clicked               (GtkButton       *button,
                                        gpointer         user_data);


void
on_ajouterRecla_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_rechercherRecla_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficherRecla_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_nut_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_heb_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_valide_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_n_valide_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_confirmAjoutRecla_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_rechercher_recl_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_backTreeRecla_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeviewRecher_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_SavemodifierRecla_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeviewCap_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_toAddCap_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_toEditCap_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_toDelCap_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_showCap_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_quitGesCap_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobuttonCap4_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonCap3_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonCap2_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonCap1_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_addCap_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_backAddCap_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_searchCap_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_editCap_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_backEdit_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobuttonCapE2_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonCapE3_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonCapE4_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonCapE1_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_capDef_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_backCapDef_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1khlil_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

gboolean
on_treeview1khlil_select_cursor_row    (GtkTreeView     *treeview,
                                        gboolean         start_editing,
                                        gpointer         user_data);

void
on_button1khlil_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button9khlil_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button2khlil_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button3khlil_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_QuitGesStock_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6khlil_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button5khlil_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton3khlil_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4khlil_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button12khlil_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button8kkhlil_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button10khlil_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button11kkhlil_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton5khlil_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton6khlil_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button13khlil_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_checkbutton1khlil_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2khlil_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button14khlil_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button37retour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4khlil_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_listeAlarmante_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_meuiMenu_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_nombreEtudiant_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_servicePR_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_listCapDef_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_reptureStock_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_quitGesMenu_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_listeCapDef_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_servicePR_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_affListeCapAlar_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_affEtudiantPNiveau_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_listeProdReptureStock_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_AffmeilleurMenu_clicked             (GtkButton       *button,
                                        gpointer         user_data);
